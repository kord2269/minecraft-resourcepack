Ksyk Chainmail Rework RP (Minecraft Java 1.20.6)

Instalacja:
1. Wrzuć ZIP do folderu .minecraft/resourcepacks albo ustaw go jako server resource pack.
2. Włącz paczkę po stronie klienta.
3. Zmienione są tylko tekstury chainmail armor: itemy i model na postaci.

Uwaga:
To jest resource pack, więc sam nie dodaje craftingu. Crafting jest w osobnym datapacku.
