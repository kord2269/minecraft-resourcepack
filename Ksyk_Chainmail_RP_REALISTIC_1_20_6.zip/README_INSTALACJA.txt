Ksyk Chainmail v2 - Resource Pack 1.20.6

Poprawiona wersja: realistyczniejsza, stalowa kolczuga z ciemnym podszyciem i skórzanym obszyciem.
Instalacja: wrzuć ZIP do .minecraft/resourcepacks albo ustaw jako server-resource-pack na Paper 1.20.6.
Ten pack zmienia tylko wygląd chainmail armor. Crafting jest w osobnym datapacku.
