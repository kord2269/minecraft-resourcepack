CharacterCards Resource Pack 1.4.3

This pack adds the custom Arcane Wand / Magic Wand texture.
The plugin uses:
- Base item: BLAZE_ROD
- CustomModelData: 97001

Install:
1. Put this ZIP in your Minecraft resourcepacks folder, or host it as a server resource pack.
2. Enable the pack in Minecraft.
3. Use /card wand as a Sorcerer to receive/update the wand.

Without this pack, the wand still works but looks like a normal Blaze Rod.
