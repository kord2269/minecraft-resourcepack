CharacterCards Resource Pack for Minecraft 1.20.6

Item:
- Sorcerer Arcane Wand
- Base item: BLAZE_ROD
- CustomModelData: 97001

To use:
- Put this ZIP into .minecraft/resourcepacks and enable it in-game,
  or host the ZIP and set it as your server resource pack.
- Your plugin must give the wand as a Blaze Rod with CustomModelData 97001.
