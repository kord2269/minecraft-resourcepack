# Obsydianowa Katana - Resource Pack

Pliki wyglądu itemu:
- assets/nederek/items/obsidian_katana.json
- assets/nederek/models/item/obsidian_katana.json
- assets/nederek/textures/item/obsidian_katana.png

Test komendą w Minecraft Java 1.21.5+:
/give @p minecraft:iron_sword[item_model="nederek:obsidian_katana",custom_name='{"text":"Obsydianowa Katana","color":"dark_purple","italic":false}'] 1

Uwaga:
- Resource pack daje tylko wygląd.
- Crafting i obrażenia muszą być dodane pluginem Paper/Spigot albo datapackiem.
- Jeśli grasz na innej wersji niż 1.21.5, może być potrzebna zmiana pack_format w pack.mcmeta.
