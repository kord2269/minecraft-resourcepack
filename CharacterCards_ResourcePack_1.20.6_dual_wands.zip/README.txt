CharacterCards Resource Pack for Minecraft 1.20.6

Included custom items:
- Arcane Wand (premium wand)
  Base item: BLAZE_ROD
  CustomModelData: 97001

- Apprentice Wand (starter wand)
  Base item: BLAZE_ROD
  CustomModelData: 97002

Usage:
- Put this ZIP into .minecraft/resourcepacks and enable it,
  or host it and use it as your server resource pack.
- Your plugin must give Sorcerer the correct base item and CMD values.
